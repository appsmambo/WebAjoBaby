$(document).ready(function(){
	$('.bxslider').bxSlider({
		auto:true,
		pager:false
	});
});